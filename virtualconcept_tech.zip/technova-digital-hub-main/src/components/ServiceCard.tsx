import { LucideIcon } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  features: string[];
}

const ServiceCard = ({ icon: Icon, title, description, features }: ServiceCardProps) => {
  return (
    <Card className="bg-card border-border hover:border-accent/50 transition-all duration-300 group">
      <CardHeader>
        <div className="mb-4">
          <Icon className="h-12 w-12 text-accent group-hover:scale-110 transition-transform" />
        </div>
        <CardTitle className="text-xl">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
              <span className="text-accent mt-0.5">•</span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        <Button variant="outline" className="w-full border-accent/50 hover:bg-accent/10">
          Learn More
        </Button>
      </CardContent>
    </Card>
  );
};

export default ServiceCard;
