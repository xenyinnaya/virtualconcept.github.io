import { Cloud, Shield, Network, Server, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Services = () => {
  const services = [
    {
      icon: Cloud,
      title: "Cloud Computing & SaaS",
      description: "Transform your business with scalable cloud solutions",
      features: [
        "Cloud Migration & Strategy",
        "Multi-Cloud Deployment (AWS, Azure, GCP)",
        "DevOps & CI/CD Pipeline Setup",
        "SaaS Application Development",
        "Cloud Cost Optimization",
        "Serverless Architecture",
        "Container Orchestration (Kubernetes, Docker)",
        "Infrastructure as Code (Terraform, CloudFormation)",
      ],
      benefits: [
        "Reduce infrastructure costs by up to 40%",
        "Scale effortlessly with demand",
        "99.99% uptime SLA",
        "24/7 monitoring and support",
      ],
    },
    {
      icon: Shield,
      title: "Cybersecurity Services",
      description: "Comprehensive security solutions to protect your digital assets",
      features: [
        "Penetration Testing & Vulnerability Assessment",
        "Security Operations Center (SOC) Monitoring",
        "Incident Response & Forensics",
        "Risk Assessment & Compliance (NIST, ISO 27001, HIPAA, PCI)",
        "Security Awareness Training",
        "Endpoint Detection & Response (EDR)",
        "Security Information & Event Management (SIEM)",
        "Zero Trust Architecture Implementation",
      ],
      benefits: [
        "Identify vulnerabilities before attackers do",
        "Ensure regulatory compliance",
        "24/7 threat monitoring",
        "Rapid incident response",
      ],
    },
    {
      icon: Network,
      title: "Networking & Security",
      description: "Enterprise-grade network infrastructure design and management",
      features: [
        "LAN/WAN Design & Implementation",
        "VPN Configuration & Management",
        "Firewall Setup (Cisco, Fortinet, Palo Alto)",
        "Network Segmentation",
        "Load Balancing & Traffic Management",
        "Network Performance Monitoring",
        "Wireless Network Design",
        "SD-WAN Implementation",
      ],
      benefits: [
        "Maximize network performance",
        "Enhanced security posture",
        "Reduced downtime",
        "Scalable infrastructure",
      ],
    },
    {
      icon: Server,
      title: "Linux Administration",
      description: "Expert Linux system management and automation",
      features: [
        "Linux Server Setup & Configuration",
        "System Hardening & Security",
        "Shell Scripting & Automation",
        "Performance Tuning & Optimization",
        "Backup & Disaster Recovery",
        "Virtualization (KVM, VMware)",
        "Container Management",
        "High Availability Clustering",
      ],
      benefits: [
        "Reliable and stable systems",
        "Automated routine tasks",
        "Improved security",
        "Cost-effective solutions",
      ],
    },
  ];

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto">
        {/* Hero Section */}
        <div className="max-w-4xl mx-auto text-center mb-20 animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Our <span className="text-accent">Services</span>
          </h1>
          <p className="text-xl text-muted-foreground">
            Comprehensive IT solutions designed to drive your business forward
          </p>
        </div>

        {/* Services Grid */}
        <div className="space-y-20">
          {services.map((service, index) => (
            <div key={index} className="animate-slide-up" style={{ animationDelay: `${index * 100}ms` }}>
              <Card className="bg-card border-border overflow-hidden">
                <CardHeader className="bg-gradient-primary/10 border-b border-border pb-8">
                  <div className="flex items-center gap-4 mb-4">
                    <service.icon className="h-12 w-12 text-accent" />
                    <div>
                      <CardTitle className="text-3xl mb-2">{service.title}</CardTitle>
                      <CardDescription className="text-lg">{service.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-8">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <h3 className="text-xl font-semibold mb-4">Features</h3>
                      <ul className="space-y-3">
                        {service.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-muted-foreground">
                            <CheckCircle2 className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-4">Key Benefits</h3>
                      <ul className="space-y-3 mb-6">
                        {service.benefits.map((benefit, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-muted-foreground">
                            <CheckCircle2 className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                      <Button className="w-full bg-gradient-primary hover:opacity-90" asChild>
                        <Link to="/contact">Request Service</Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-20 text-center">
          <Card className="bg-gradient-primary border-0 text-white">
            <CardContent className="p-12">
              <h2 className="text-4xl font-bold mb-4">Need a Custom Solution?</h2>
              <p className="text-xl mb-8 opacity-90">
                Let's discuss your specific requirements and create a tailored solution
              </p>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary" asChild>
                <Link to="/contact">Contact Our Team</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Services;
