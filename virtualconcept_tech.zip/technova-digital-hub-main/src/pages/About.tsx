import { Award, Target, Users, Zap } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const About = () => {
  const values = [
    {
      icon: Target,
      title: "Mission-Driven",
      description: "Empowering businesses with cutting-edge IT solutions that drive innovation and growth.",
    },
    {
      icon: Zap,
      title: "Innovation First",
      description: "Staying ahead of technology trends to deliver future-ready solutions.",
    },
    {
      icon: Users,
      title: "Client-Focused",
      description: "Building long-term partnerships through exceptional service and results.",
    },
    {
      icon: Award,
      title: "Excellence",
      description: "Maintaining the highest standards in security, quality, and performance.",
    },
  ];

  const certifications = [
    "AWS Certified Solutions Architect",
    "Azure Solutions Architect Expert",
    "Google Cloud Professional",
    "CISSP - Certified Information Systems Security Professional",
    "CEH - Certified Ethical Hacker",
    "CCNP - Cisco Certified Network Professional",
    "CompTIA Security+",
    "RHCE - Red Hat Certified Engineer",
  ];

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto">
        {/* Hero Section */}
        <div className="max-w-4xl mx-auto text-center mb-20 animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            About <span className="text-accent">Virtual Concept Technologies</span>
          </h1>
          <p className="text-xl text-muted-foreground leading-relaxed">
            We are a team of passionate IT professionals dedicated to connecting your digital imagination to reality through innovative solutions in cloud computing, cybersecurity, networking, and Linux administration.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-8 mb-20">
          <Card className="bg-card border-border">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold mb-4 text-accent">Our Mission</h2>
              <p className="text-muted-foreground leading-relaxed">
                To deliver enterprise-grade IT solutions that empower businesses to thrive in the digital age. We combine technical excellence with strategic thinking to solve complex challenges and drive sustainable growth for our clients.
              </p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold mb-4 text-accent">Our Vision</h2>
              <p className="text-muted-foreground leading-relaxed">
                To be the most trusted partner for businesses seeking secure, scalable, and future-ready IT infrastructure. We envision a world where technology seamlessly enables innovation and creates limitless possibilities.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Values */}
        <div className="mb-20">
          <h2 className="text-4xl font-bold text-center mb-12">Our Core Values</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="bg-card border-border hover:border-accent/50 transition-all">
                <CardContent className="p-6 text-center">
                  <value.icon className="h-12 w-12 text-accent mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">Certifications & Credentials</h2>
          <Card className="bg-card border-border">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-4">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Award className="h-5 w-5 text-accent flex-shrink-0" />
                    <span className="text-muted-foreground">{cert}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Team Section */}
        <div className="mt-20">
          <h2 className="text-4xl font-bold text-center mb-4">Our Leadership Team</h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Led by industry veterans with decades of combined experience in enterprise IT
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Dr. James Mitchell", role: "Chief Executive Officer", expertise: "Cloud Architecture & Strategy" },
              { name: "Sarah Thompson", role: "Chief Technology Officer", expertise: "Cybersecurity & Compliance" },
              { name: "David Kumar", role: "Chief Security Officer", expertise: "Network Security & Infrastructure" },
            ].map((member, index) => (
              <Card key={index} className="bg-card border-border text-center">
                <CardContent className="p-8">
                  <div className="w-24 h-24 rounded-full bg-gradient-primary mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
                  <p className="text-accent mb-2">{member.role}</p>
                  <p className="text-sm text-muted-foreground">{member.expertise}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
