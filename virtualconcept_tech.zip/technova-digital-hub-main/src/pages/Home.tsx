import { Cloud, Shield, Network, Server, ArrowRight, CheckCircle2, Users, Award, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import ServiceCard from "@/components/ServiceCard";
import { Link } from "react-router-dom";

const Home = () => {
  const services = [
    {
      icon: Cloud,
      title: "Cloud Computing & SaaS",
      description: "Scalable cloud solutions for modern businesses",
      features: [
        "Multi-cloud deployment (AWS, Azure, GCP)",
        "Cloud migration & optimization",
        "DevOps & automation",
        "SaaS application setup",
      ],
    },
    {
      icon: Shield,
      title: "Cybersecurity",
      description: "Comprehensive security solutions to protect your assets",
      features: [
        "Penetration testing",
        "SOC monitoring & incident response",
        "Risk & compliance management",
        "Security audits & assessments",
      ],
    },
    {
      icon: Network,
      title: "Networking & Security",
      description: "Enterprise-grade network infrastructure",
      features: [
        "LAN/WAN design & implementation",
        "VPN & firewall configuration",
        "Network monitoring",
        "Performance optimization",
      ],
    },
    {
      icon: Server,
      title: "Linux Administration",
      description: "Expert Linux system management",
      features: [
        "Server setup & hardening",
        "Shell scripting & automation",
        "Virtualization & containers",
        "CI/CD integration",
      ],
    },
  ];

  const stats = [
    { icon: Users, label: "Clients Served", value: "500+" },
    { icon: Award, label: "Certifications", value: "50+" },
    { icon: TrendingUp, label: "Success Rate", value: "99%" },
    { icon: CheckCircle2, label: "Projects Completed", value: "1000+" },
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "CTO, TechCorp",
      content: "Virtual Concept Technologies transformed our cloud infrastructure. Their expertise is unmatched.",
      rating: 5,
    },
    {
      name: "Michael Chen",
      role: "Security Director, FinanceHub",
      content: "The cybersecurity solutions provided gave us peace of mind. Professional and thorough.",
      rating: 5,
    },
    {
      name: "Emily Rodriguez",
      role: "IT Manager, HealthTech",
      content: "Outstanding training programs. Our team's skills improved dramatically after their courses.",
      rating: 5,
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-50" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzMzMyIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-20" />
        
        <div className="container mx-auto relative z-10">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Secure. Scalable.{" "}
              <span className="text-gradient-accent">Future-Ready</span>
              <br />
              IT Solutions
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8">
              Connecting your digital imagination to reality through innovative technology and expert services
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-primary hover:opacity-90 text-lg px-8">
                Request IT Services
                <ArrowRight className="ml-2" />
              </Button>
              <Button size="lg" variant="outline" className="border-accent/50 hover:bg-accent/10 text-lg px-8" asChild>
                <Link to="/training">View Training Programs</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 border-y border-border bg-card/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center animate-slide-up" style={{ animationDelay: `${index * 100}ms` }}>
                <stat.icon className="h-8 w-8 text-accent mx-auto mb-2" />
                <div className="text-3xl font-bold mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Our Services</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive IT solutions tailored to your business needs
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <div key={index} className="animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
                <ServiceCard {...service} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-card/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-xl text-muted-foreground">Trusted by industry leaders worldwide</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <span key={i} className="text-accent">★</span>
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <Card className="bg-gradient-primary border-0 text-white">
            <CardContent className="p-12 text-center">
              <h2 className="text-4xl font-bold mb-4">Ready to Transform Your IT Infrastructure?</h2>
              <p className="text-xl mb-8 opacity-90">
                Let's discuss how we can help secure and scale your business
              </p>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary" asChild>
                <Link to="/contact">Get In Touch</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Home;
