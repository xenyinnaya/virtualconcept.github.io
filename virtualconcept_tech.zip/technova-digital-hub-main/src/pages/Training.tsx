import { Clock, DollarSign, BookOpen, Award } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";

const Training = () => {
  const courses = [
    {
      category: "Cloud & DevOps",
      courses: [
        {
          title: "AWS Solutions Architect Professional",
          duration: "8 weeks",
          cost: "$2,499",
          level: "Advanced",
          description: "Master AWS architecture design and deployment strategies",
          topics: ["EC2, S3, VPC", "Lambda & Serverless", "High Availability", "Cost Optimization"],
        },
        {
          title: "Azure Cloud Administrator",
          duration: "6 weeks",
          cost: "$1,999",
          level: "Intermediate",
          description: "Learn to manage Azure cloud infrastructure",
          topics: ["Azure Resources", "Virtual Networks", "Identity Management", "Monitoring"],
        },
        {
          title: "Kubernetes Administration",
          duration: "4 weeks",
          cost: "$1,799",
          level: "Intermediate",
          description: "Container orchestration and management with Kubernetes",
          topics: ["Cluster Setup", "Pod Management", "Services & Networking", "Security"],
        },
      ],
    },
    {
      category: "Cybersecurity",
      courses: [
        {
          title: "Certified Ethical Hacker (CEH) Prep",
          duration: "10 weeks",
          cost: "$2,799",
          level: "Advanced",
          description: "Comprehensive ethical hacking and penetration testing",
          topics: ["Footprinting", "Network Scanning", "Exploitation", "Web App Security"],
        },
        {
          title: "SOC Analyst Bootcamp",
          duration: "8 weeks",
          cost: "$2,499",
          level: "Intermediate",
          description: "Security operations center analysis and response",
          topics: ["Threat Detection", "SIEM Tools", "Incident Response", "Forensics"],
        },
        {
          title: "Network Defense & Security",
          duration: "6 weeks",
          cost: "$1,999",
          level: "Intermediate",
          description: "Protect networks from modern threats",
          topics: ["Firewall Configuration", "IDS/IPS", "VPN Security", "Network Monitoring"],
        },
      ],
    },
    {
      category: "Networking",
      courses: [
        {
          title: "Cisco CCNA Certification",
          duration: "8 weeks",
          cost: "$2,199",
          level: "Beginner",
          description: "Foundation in Cisco networking",
          topics: ["Network Fundamentals", "IP Connectivity", "Security Fundamentals", "Automation"],
        },
        {
          title: "Cisco CCNP Enterprise",
          duration: "12 weeks",
          cost: "$3,299",
          level: "Advanced",
          description: "Advanced enterprise networking solutions",
          topics: ["Advanced Routing", "VPN Technologies", "Network Design", "Troubleshooting"],
        },
        {
          title: "Fortinet Network Security",
          duration: "4 weeks",
          cost: "$1,599",
          level: "Intermediate",
          description: "Fortinet firewall and security solutions",
          topics: ["FortiGate Configuration", "Security Policies", "VPN Setup", "Monitoring"],
        },
      ],
    },
    {
      category: "Linux Administration",
      courses: [
        {
          title: "Red Hat Certified Engineer (RHCE)",
          duration: "10 weeks",
          cost: "$2,899",
          level: "Advanced",
          description: "Advanced Linux system administration",
          topics: ["System Configuration", "Network Services", "Security", "Automation with Ansible"],
        },
        {
          title: "Linux System Administration",
          duration: "6 weeks",
          cost: "$1,799",
          level: "Beginner",
          description: "Essential Linux administration skills",
          topics: ["Command Line", "File Systems", "User Management", "Package Management"],
        },
        {
          title: "Bash Scripting & Automation",
          duration: "4 weeks",
          cost: "$1,299",
          level: "Intermediate",
          description: "Automate tasks with shell scripting",
          topics: ["Script Basics", "Control Structures", "Functions", "Advanced Techniques"],
        },
      ],
    },
  ];

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Beginner":
        return "bg-accent/20 text-accent";
      case "Intermediate":
        return "bg-primary/20 text-primary";
      case "Advanced":
        return "bg-destructive/20 text-destructive";
      default:
        return "bg-muted";
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto">
        {/* Hero Section */}
        <div className="max-w-4xl mx-auto text-center mb-20 animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Training <span className="text-accent">Programs</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            Industry-leading courses designed by experts to advance your IT career
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-accent" />
              <span>Industry Certifications</span>
            </div>
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-accent" />
              <span>Hands-on Labs</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-accent" />
              <span>Flexible Schedule</span>
            </div>
          </div>
        </div>

        {/* Courses by Category */}
        <div className="space-y-16">
          {courses.map((category, catIndex) => (
            <div key={catIndex} className="animate-fade-in" style={{ animationDelay: `${catIndex * 100}ms` }}>
              <h2 className="text-3xl font-bold mb-8 text-accent">{category.category}</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.courses.map((course, courseIndex) => (
                  <Card key={courseIndex} className="bg-card border-border hover:border-accent/50 transition-all flex flex-col">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-2">
                        <CardTitle className="text-xl">{course.title}</CardTitle>
                        <Badge className={getLevelColor(course.level)}>{course.level}</Badge>
                      </div>
                      <CardDescription>{course.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="flex-grow flex flex-col">
                      <div className="space-y-4 mb-6 flex-grow">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4 text-accent" />
                          <span>{course.duration}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <DollarSign className="h-4 w-4 text-accent" />
                          <span>{course.cost}</span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-sm mb-2">What You'll Learn:</h4>
                          <ul className="space-y-1">
                            {course.topics.map((topic, idx) => (
                              <li key={idx} className="text-sm text-muted-foreground flex items-center gap-2">
                                <span className="text-accent">•</span>
                                {topic}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                      <Button className="w-full bg-gradient-primary hover:opacity-90" asChild>
                        <Link to="/contact">Enroll Now</Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-20">
          <Card className="bg-gradient-primary border-0 text-white">
            <CardContent className="p-12 text-center">
              <h2 className="text-4xl font-bold mb-4">Need a Custom Training Program?</h2>
              <p className="text-xl mb-8 opacity-90">
                We offer tailored corporate training solutions for teams of all sizes
              </p>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary" asChild>
                <Link to="/contact">Contact Us for Corporate Training</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Training;
