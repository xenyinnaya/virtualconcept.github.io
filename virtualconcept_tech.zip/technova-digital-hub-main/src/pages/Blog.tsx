import { Calendar, User, ArrowRight } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const Blog = () => {
  const posts = [
    {
      title: "The Future of Cloud Computing: Trends to Watch in 2025",
      excerpt: "Explore emerging cloud technologies and how they're reshaping enterprise IT infrastructure.",
      category: "Cloud",
      author: "Dr. James Mitchell",
      date: "2025-01-15",
      readTime: "8 min read",
    },
    {
      title: "Zero Trust Security: Implementation Best Practices",
      excerpt: "A comprehensive guide to implementing zero trust architecture in your organization.",
      category: "Security",
      author: "Sarah Thompson",
      date: "2025-01-10",
      readTime: "12 min read",
    },
    {
      title: "Kubernetes Security: Essential Strategies for 2025",
      excerpt: "Learn how to secure your Kubernetes clusters against modern threats.",
      category: "Cloud",
      author: "David Kumar",
      date: "2025-01-05",
      readTime: "10 min read",
    },
    {
      title: "SD-WAN vs Traditional WAN: Making the Right Choice",
      excerpt: "Compare SD-WAN and traditional WAN solutions for your enterprise network.",
      category: "Networking",
      author: "Michael Chen",
      date: "2024-12-28",
      readTime: "7 min read",
    },
    {
      title: "Linux Performance Tuning: Advanced Techniques",
      excerpt: "Optimize your Linux systems for maximum performance and efficiency.",
      category: "Linux",
      author: "Emily Rodriguez",
      date: "2024-12-20",
      readTime: "15 min read",
    },
    {
      title: "AI-Powered Threat Detection: The Next Frontier",
      excerpt: "How artificial intelligence is revolutionizing cybersecurity threat detection.",
      category: "Security",
      author: "Sarah Thompson",
      date: "2024-12-15",
      readTime: "9 min read",
    },
  ];

  const categories = ["All", "Cloud", "Security", "Networking", "Linux"];

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto">
        {/* Hero Section */}
        <div className="max-w-4xl mx-auto text-center mb-16 animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Knowledge <span className="text-accent">Hub</span>
          </h1>
          <p className="text-xl text-muted-foreground">
            Insights, tutorials, and best practices from our expert team
          </p>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={category === "All" ? "default" : "outline"}
              className={category === "All" ? "bg-gradient-primary" : "border-accent/50 hover:bg-accent/10"}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Featured Post */}
        <Card className="bg-card border-border mb-12 overflow-hidden">
          <div className="grid md:grid-cols-2">
            <div className="bg-gradient-primary/20 min-h-[300px]" />
            <CardContent className="p-8 flex flex-col justify-center">
              <Badge className="w-fit mb-4 bg-accent/20 text-accent">Featured</Badge>
              <CardTitle className="text-3xl mb-4">{posts[0].title}</CardTitle>
              <CardDescription className="text-lg mb-6">{posts[0].excerpt}</CardDescription>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                <div className="flex items-center gap-1">
                  <User className="h-4 w-4" />
                  {posts[0].author}
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {posts[0].date}
                </div>
              </div>
              <Button className="w-fit bg-gradient-primary hover:opacity-90">
                Read Article <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </div>
        </Card>

        {/* Blog Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts.slice(1).map((post, index) => (
            <Card key={index} className="bg-card border-border hover:border-accent/50 transition-all flex flex-col">
              <div className="bg-gradient-primary/20 h-48" />
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge className="bg-accent/20 text-accent">{post.category}</Badge>
                  <span className="text-xs text-muted-foreground">{post.readTime}</span>
                </div>
                <CardTitle className="text-xl hover:text-accent transition-colors cursor-pointer">
                  {post.title}
                </CardTitle>
                <CardDescription>{post.excerpt}</CardDescription>
              </CardHeader>
              <CardContent className="mt-auto">
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    {post.author}
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {post.date}
                  </div>
                </div>
                <Button variant="outline" className="w-full border-accent/50 hover:bg-accent/10">
                  Read More <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Newsletter CTA */}
        <div className="mt-20">
          <Card className="bg-gradient-primary border-0 text-white">
            <CardContent className="p-12 text-center">
              <h2 className="text-4xl font-bold mb-4">Stay Updated</h2>
              <p className="text-xl mb-8 opacity-90">
                Subscribe to our newsletter for the latest insights and updates
              </p>
              <div className="max-w-md mx-auto flex gap-2">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-2 rounded bg-white/10 border border-white/20 text-white placeholder:text-white/60"
                />
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                  Subscribe
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Blog;
